=== ConstructionPress Demo Importer ===
Contributors: ConstructionPress Teams
Author URI: https://hvthemes.com/about/
Plugin URL: https://hvthemes.com/
Requires at Least: 4.4
Tested Up To: 5.7
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: shortcodes, demo, page builder, woocommerce

ConstructionPress Demo Importer add extra features to HV Themes theme like widgets, WooCommerce options, one click demo import and much more.

== Description ==

ConstructionPress Demo Importer add extra features and options to [HV Themes](https://hvthemes.com/) theme.
This plugin require the free WP theme - [HV Themes](https://wordpress.org/themes/hello-hv/) - to be installed.

**Features:**
- One click demo import - import starter sites with one click. [Demos here](https://hvthemes.com/demos/)
- 100% WooCommerce support and custom WooCommerce options and features

[Documentation](https://www.hvthemes.com/theme-documentation/)

= Page Builders Friend =

HV Themes & ConstructionPress Demo Importer is best friend with the popular pagebuilders like Elementor, Beaver Builder, King Composer, Brizy, Visual Composer, SiteOrigin, Divi or Gutenberg.

= 10+ free demos sites =

10+ free demo websites ready to import are included. Importing is easy with a few clicks.

= 100% WooCommerce support =

Extend the WooCommerce with new options and features. Import full WooCommerce demo websites with few clicks and be ready to start your new store in few minutes.

== Installation ==

1. Upload `constructionpress-demo-importer` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done!

== Frequently Asked Questions ==

= I installed the plugin but it does not work =

This plugin will only work with the [HV Themes](https://hvthemes.com/) theme.

== Changelog ==

= 1.0.0 =
* First release.


== Credits & Copyright ==

= Typed.js, Copyright 2014 Matt Bold =
Licenses: MIT
Source: https://github.com/mattboldt/typed.js