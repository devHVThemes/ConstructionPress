<?php
/**
 * Plugin Name: ConstructionPress Demo Importer
 * Plugin URI: https://constructionpress.com/demo-importer/
 * Description: Import ConstructionPress official themes demo content, widgets and theme settings with just one click.
 * Version: 1.0.0
 * Author: ConstructionPress Teams
 * Author URI: https://constructionpress.com
 * License: GPLv3 or later
 * Text Domain: constructionpress-demo-importer
 * Domain Path: /languages/
 *
 */
// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('add_action')) {
    die('Nothing to do...');
}

$plugin_data = get_file_data(__FILE__, array('Version' => 'Version'), false);
$plugin_version = $plugin_data['Version'];
// Define WC_PLUGIN_FILE.
if (!defined('CONSTRUCTIONPRESS_DEMO_IMPORTER_CURRENT_VERSION')) {
    define('CONSTRUCTIONPRESS_DEMO_IMPORTER_CURRENT_VERSION', $plugin_version);
}

//plugin constants
define('CONSTRUCTIONPRESS_DEMO_IMPORTER_PATH', plugin_dir_path(__FILE__));
define('CONSTRUCTIONPRESS_DEMO_IMPORTER_PLUGIN_BASE', plugin_basename(__FILE__));
define('CONSTRUCTIONPRESS_DEMO_IMPORTER_PLUGIN_URL', plugins_url('/', __FILE__));


add_action('plugins_loaded', 'constructionpress_demo_importer_load_textdomain');

function constructionpress_demo_importer_load_textdomain() {
    load_plugin_textdomain('constructionpress-demo-importer', false, basename(dirname(__FILE__)) . '/languages/');
}

function constructionpress_demo_importer_scripts() {
    wp_enqueue_style('constructionpress-demo-importer', plugin_dir_url(__FILE__) . 'css/style.css', array(), CONSTRUCTIONPRESS_DEMO_IMPORTER_CURRENT_VERSION);
    wp_enqueue_script('constructionpress-demo-importer-js', plugin_dir_url(__FILE__) . 'js/constructionpress-demo-importer.js', array('jquery'), CONSTRUCTIONPRESS_DEMO_IMPORTER_CURRENT_VERSION, true);
}

add_action('wp_enqueue_scripts', 'constructionpress_demo_importer_scripts');

include_once( plugin_dir_path(__FILE__) . 'lib/demo/constructionpress-demos.php' );

/**
 * Redirect after plugin activation
 */
function constructionpress_demo_importer_plugin_redirect() {
    if (get_option('fe_plugin_do_activation_redirect', false)) {
        delete_option('fe_plugin_do_activation_redirect');
        if (!is_network_admin() || !isset($_GET['activate-multi'])) {
            wp_redirect('themes.php?page=demo-importer');
        }
    }
}

include_once( plugin_dir_path(__FILE__) . 'lib/shortcodes/bs4shortcodes.php' );

/**
 * Remove Metadata on plugin Deactivation.
 */
function constructionpress_demo_importer_deactivate() {
    delete_option('hello_hv_active_time');
    delete_option('hello_hv_maybe_later');
    delete_option('hello_hv_review_dismiss');
    delete_option('hello_hv_active_pro_time');
}
register_deactivation_hook(__FILE__, 'constructionpress_demo_importer_deactivate');

add_image_size( 'img_409_320', 409, 320, true );
add_image_size( 'img_400_500', 400, 500, true );

function hv_excerpt($limit) {
    $excerpt = explode(' ', get_the_excerpt(), $limit);
    if (count($excerpt)>=$limit) {
        array_pop($excerpt);
        $excerpt = implode(" ",$excerpt).'...';
    } else {
        $excerpt = implode(" ",$excerpt);
    }
    $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
    return $excerpt;
}


remove_filter( 'wp_import_post_meta', 'Elementor\Compatibility::on_wp_import_post_meta');
remove_filter( 'wxr_importer.pre_process.post_meta', 'Elementor\Compatibility::on_wxr_importer_pre_process_post_meta');

/* ----------- Project Post Type -------------- */
function create_posttype() {
  
    register_post_type( 'project',
        array(
            'labels' => array(
                'name' => __( 'Projects' ),
                'singular_name' => __( 'Project' )
            ),
            'public' => true,
            'has_archive' => true,
            'rewrite' => array('slug' => 'project'),
            'show_in_rest' => true,
        )
    );
}
add_action( 'init', 'create_posttype' );
