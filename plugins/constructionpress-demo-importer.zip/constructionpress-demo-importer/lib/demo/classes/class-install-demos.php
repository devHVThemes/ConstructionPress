<?php
/**
 * Install demos page
 *
 * @package ConstructionPress_Demo_Importer
 * @category Core
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Start Class
class FWP_Install_Demos {

	/**
	 * Start things up
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'add_page' ), 999 );
	}

	/**
	 * Add sub menu page for the custom CSS input
	 *
	 * @since 1.0.0
	 */
	public function add_page() {

		$title = esc_html__( 'Demo Importer', 'constructionpress-demo-importer' );

		add_submenu_page(
			'themes.php',
			esc_html__( 'Demo Importer', 'constructionpress-demo-importer' ),
			$title,
			'manage_options',
			'demo-importer',
			array( $this, 'create_admin_page' )
		);
	}

	/**
	 * Settings page output
	 *
	 * @since 1.0.0
	 */
	public function create_admin_page() {

		// Theme branding
		$brand = 'ConstructionPress'; ?>

		<div class="fwp-demo-wrap wrap">
			<div class="constructionpress-importer-heading">
				<h2><?php echo esc_attr( $brand ); ?> - <?php esc_attr_e( 'Demo Importer', 'constructionpress-demo-importer' ); ?></h2>
			</div>

			<div class="theme-browser rendered">

				<?php
				// Vars
				$demos = ConstructionPressTeams_Demos::get_demos_data();
				$categories = ConstructionPressTeams_Demos::get_demo_all_categories( $demos ); ?>

				<?php if ( ! empty( $categories ) ) : ?>
					<div class="fwp-header-bar">
						<nav class="fwp-navigation">
							<ul>
								<li class="active"><a href="#all" class="fwp-navigation-link"><?php esc_html_e( 'All', 'constructionpress-demo-importer' ); ?></a></li>
								<?php foreach ( $categories as $key => $name ) : ?>
									<li><a href="#<?php echo esc_attr( $key ); ?>" class="fwp-navigation-link"><?php echo esc_html( $name ); ?></a></li>
								<?php endforeach; ?>
							</ul>
						</nav>
						<div clas="fwp-search">
							<input type="text" class="fwp-search-input" name="fwp-search" value="" placeholder="<?php esc_html_e( 'Search demos...', 'constructionpress-demo-importer' ); ?>">
						</div>
					</div>
				<?php endif; ?>

				<div class="themes wp-clearfix">

					<?php
					// Loop through all demos
					foreach ( $demos as $demo => $key ) {

						// Vars
						$item_categories = ConstructionPressTeams_Demos::get_demo_item_categories( $key );
			            $title = str_replace( 'demo', '', $demo );
			            $title = str_replace( '-', ' ', $title );
			            $pro = $key['required_plugins'];
			            $demo_url = $key['demo_url'];
            ?>

						<div class="theme-wrap" data-categories="<?php echo esc_attr( $item_categories ); ?>" data-name="<?php echo esc_attr( strtolower( $demo ) ); ?>">
							<div class="theme fwp-open-popup" data-demo-id="<?php echo esc_attr( $demo ); ?>">
								<div class="theme-screenshot">
									<img src="https://raw.githubusercontent.com/devHVThemes/ConstructionPress/main/screenshot/<?php echo esc_attr( $demo ); ?>.jpg" />
									<?php	if ( isset($pro['premium']) && $pro['premium'] != '' )  { ?>
					                    <div class="pro-badge">
					  						<?php esc_html_e( 'PRO', 'constructionpress-demo-importer' ); ?>
					  					</div>
					                <?php } ?>
									<div class="demo-import-loader preview-all preview-all-<?php echo esc_attr( $demo ); ?>"></div>
									<div class="demo-import-loader preview-icon preview-<?php echo esc_attr( $demo ); ?>"><i class="custom-loader"></i></div>
								</div>
								<div class="theme-id-container">
									<h2 class="theme-name" id="<?php echo esc_attr( $demo ); ?>"><span><?php echo ucwords( $title ); ?></span></h2>
									<div class="theme-actions">
										<a href="javascript:void(0)" class="button button-primary fwp-open-popup" data-demo-id="<?php echo esc_attr( $demo ); ?>">Import</a>
										<a class="button button-info" href="<?php echo esc_attr( $demo_url ); ?>" target="_blank"><?php _e( 'Preview', 'constructionpress-demo-importer' ); ?></a>
									</div>
								</div>
							</div>
						</div>

					<?php } ?>

				</div>

			</div>

		</div>

	<?php }
}
new FWP_Install_Demos();