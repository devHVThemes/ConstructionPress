<?php
add_shortcode('constructionpress-blog', 'constructionpress_latest_blog');
function constructionpress_latest_blog($atts){
	//ob_start();
	$return_string = '';
	extract( shortcode_atts( array(
		'styles' => '',     	// '', 'masonry', 'masonry2', 'masonry3', 'columnview', 'fullwide', 'grid', 'grid2', 'grid3', 'leftside-image', 'image-under-text', 'image-under-text-2', 'widget-post'
		'limit' => '-1',    	// -1 == all posts
		'col'	=> '3',			//	blog coloum	
		'category_id' => '',    // '' == all category
		'post__not_in' => array(1),
	), $atts ) );

	if(!empty($category_id)){
		$blog_args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => $limit,
			'cat' => $category_id
		);
	} else {
		$blog_args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => $limit
		);
	}

	$blog_data = new WP_Query($blog_args);
	if($styles == 'masonry'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="masonry-wrapper">';
			$return_string .= '<div class="container">';
			$return_string .= '<div class="row masonry">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				if($col == '4'){
					$return_string .= '<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">';
				}elseif($col == '3'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">';
				}elseif($col == '2'){
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">';
				}else{
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">';
				}

				$return_string .= '<div class="item">';
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'medium', array( 'class' => 'alignleft' ) );
				} else {
					$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
				}
				$return_string .= '<a href="'.get_permalink().'" class="img_wrap">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="hotels">';
				$return_string .= '<div class="short-post-meta">'.get_the_category_list(', ').' | '.get_the_time('M j, Y').'</div>';
				$return_string .= '<h3>'.get_the_title().'</h3>';
				$return_string .= '<p>'.hv_excerpt(20).'</p>';
				$return_string .= '<div class="readmore"><a href="'.get_permalink().'">Read More &nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
		}
	}elseif ($styles == 'masonry2'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="masonry-wrapper">';
			$return_string .= '<div class="container">';
			$return_string .= '<div class="masonry2">';
				while($blog_data->have_posts()) : $blog_data->the_post();
					$return_string .= '<div class="item">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'large', array( 'class' => 'alignleft' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
					$return_string .= '<a href="'.get_permalink().'" class="img_wrap">'.$post_thumbnail.'</a>';
					$return_string .= '<div class="contentpadding">';
					$return_string .= '<div class="short-post-meta">'.get_the_category_list(', ').' | '.get_the_time('M j, Y').'</div>';
					$return_string .= '<h3>'.get_the_title().'</h3>';
					$return_string .= '<p>'.hv_excerpt(50).'</p>';
					$return_string .= '<div class="readmore"><a href="'.get_permalink().'">Read More &nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></div>';
					$return_string .= '</div>';
					$return_string .= '</div>';
				endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
		}
	}elseif($styles == 'masonry3'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="hvblog-wrapper">';
			$return_string .= '<div class="container">';
			$return_string .= '<div class="row row2">';
			$return_string .= '<div class="col-xl-12">';
			$return_string .= '<ul>';
			while($blog_data->have_posts()) : $blog_data->the_post();
				$return_string .= '<li>';
				$return_string .= '<ul>';
				$return_string .= '<li>';
				$return_string .= '<h3>'.get_the_title().'</h3>';
				$return_string .= hv_excerpt(20);
				$return_string .= '</li>';
				$return_string .= '<li>';
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'medium', array( 'class' => 'alignleft' ) );
				} else {
					$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
				}
				$return_string .= $post_thumbnail;
				$return_string .= '</li>';
				$return_string .= '</ul>';
				$return_string .= '</li>';
			endwhile;
			$return_string .= '</ul>';
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
		}
	}elseif($styles == 'fullwide'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="hvblog-wrapper3">';
			$return_string .= '<div class="container">';
			$return_string .= '<div class="row">';
			$return_string .= '<div class="col-xl-12">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				$return_string .= '<div class="item">';
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'alignleft' ) );
				} else {
					$post_thumbnail = '';
				}
				$return_string .= '<a href="'.get_permalink().'">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="contentpadding">';
				$return_string .= '<div class="short-post-meta">'.get_the_category_list(', ').' | '.get_the_time('M j, Y').'</div>';
				$return_string .= '<h2>'.get_the_title().'</h2>';
				$return_string .= '<p>'.get_the_excerpt().'</p>';
				$return_string .= '<div class="readmore"><a href="'.get_permalink().'">Read More &nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
		}
	}elseif($styles == 'columnview'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="hvblog-wrapper">';
			$return_string .= '<div class="container">';
			$return_string .= '<div class="row">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				if($limit == 3){
					$return_string .= '<div class="col-xl-4">';
				} else {
					$return_string .= '<div class="col-xl-3">';
				}
				$return_string .= '<div class="item">';
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
				} else {
					$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
				}
				$return_string .= '<a href="'.get_permalink().'" class="img_wrap">'.$post_thumbnail.'</a>';
				$return_string .= '<h3>'.get_the_title().'</h3>';
				$return_string .= '<p>'.hv_excerpt(20).'</p>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
		}
	}elseif($styles == 'grid'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="design-wrapper">';
			$return_string .= '<div class="row design1">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				if($col == '3'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'img_409_320', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				}elseif($col == '1'){
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				
				}elseif($col == '2'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				
				}else{
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'img_409_320', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				}
				$return_string .= '<div class="item">';
				$return_string .= '<a href="'.get_permalink().'" class="img_wrap">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="content">';
				$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
				$return_string .= '<div class="short-post-meta">'.get_the_time('M j').' <i class="fa fa-circle" aria-hidden="true"></i> '.get_the_category_list(', ').' </div>';
				$return_string .= '<div class="divider"></div>';
				$return_string .= '<p>'.hv_excerpt(20).'</p>';
				$return_string .= '<div class="readmore"><a href="'.get_permalink().'">Read More &nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
		}
	}elseif($styles == 'grid2'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="design-wrapper">';
			$return_string .= '<div class="row design2">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				if($col == '3'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'img_409_320', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				}elseif($col == '1'){
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				}elseif($col == '2'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				}else{
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'img_409_320', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				}
				$return_string .= '<div class="item">';
				$return_string .= '<a href="'.get_permalink().'"  class="img_wrap">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="content">';
				$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
				$return_string .= '<div class="short-post-meta">'.get_the_time('M j').' <i class="fa fa-circle" aria-hidden="true"></i> '.get_the_category_list(', ').' </div>';
				$return_string .= '<div class="divider"></div>';
				$return_string .= '<p>'.hv_excerpt(20).'</p>';
				$return_string .= '<div class="readmore"><a href="'.get_permalink().'">Read More &nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
		}
	}elseif($styles == 'grid3'){
		if($blog_data->have_posts()){

			$return_string .= '<div class="design-wrapper">';
			$return_string .= '<div class="row design3">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				
				if($col == '3'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">';
					
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'img_409_320', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				
				}elseif($col == '1'){
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				
				}elseif($col == '2'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				
				}else{
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3 col-xl-3">';
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'img_409_320', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				}

				$return_string .= '<div class="item">';
				$return_string .= '<a href="'.get_permalink().'">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="post-meta-date">'.get_the_time('F d, Y').' </div>';
				$return_string .= '<div class="content">';
				$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
				$return_string .= '<div class="short-post-meta">'.get_the_category_list(', ').' </div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
				
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
			
		}	
	}elseif($styles == 'leftside-image') {
		if($blog_data->have_posts()){
			$return_string .= '<div class="design-wrapper">';
			$return_string .= '<div class="row leftside-image">';
			$return_string .= '<div class="col-xl-12">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				$return_string .= '<div class="item">';
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'img_409_320', array( 'class' => 'alignleft' ) );
				} else {
					$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
				}
				$return_string .= '<a href="'.get_permalink().'" class="img_wrap">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="contentpadding">';
				$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
				$return_string .= '<div class="short-post-meta">'.get_the_time('M j').' <i class="fa fa-circle" aria-hidden="true"></i> '.get_the_category_list(', ').' </div>';
				$return_string .= '<div class="divider"></div>';
				$return_string .= '<p>'.hv_excerpt(10).'</p>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
		}
	}elseif($styles == 'image-under-text'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="design-wrapper">';
			$return_string .= '<div class="row image-text">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				if($col == '1'){
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">';
				}else{
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">';
				}
				$return_string .= '<div class="item">';
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
				} else {
					$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
				}
				$return_string .= '<a href="'.get_permalink().'">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="overlay"></div>';
				$return_string .= '<div class="content">';
				$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
				$return_string .= '<div class="short-post-meta">'.get_the_time('M j').' <i class="fa fa-circle" aria-hidden="true"></i> '.get_the_category_list(', ').' </div>';
				$return_string .= '<div class="divider"></div>';
				$return_string .= '<p>'.hv_excerpt(20).'</p>';
				$return_string .= '<div class="readmore"><a href="'.get_permalink().'">Read More &nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
		}	
	}elseif($styles == 'image-under-text-2'){
		if($blog_data->have_posts()){
			$return_string .= '<div class="design-wrapper">';
			$return_string .= '<div class="row design2 image-text">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				if($col == '1'){
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">';
				}elseif($col == '2'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">';
				}else{
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4 col-xl-4">';
				}
				$return_string .= '<div class="item">';
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'img_400_500', array( 'class' => 'aligncenter' ) );
				} else {
					$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
				}
				$return_string .= '<a href="'.get_permalink().'">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="overlay"></div>';
				$return_string .= '<div class="content">';
				$return_string .= '<div class="short-post-meta">'.get_the_time('M j').' <i class="fa fa-circle" aria-hidden="true"></i> '.get_the_category_list(', ').' </div>';
				$return_string .= '<div class="divider"></div>';
				$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
				$return_string .= '</div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
		}	
	}elseif($styles == 'widget-post') {
		if($blog_data->have_posts()){
			$return_string .= '<div class="design-wrapper">';
			$return_string .= '<div class="row leftside-image widget_post">';
			$return_string .= '<div class="col-xl-12">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				$return_string .= '<div class="item">';
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'thumbnail', array( 'class' => 'alignleft' ) );
				} else {
					$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
				}
				$return_string .= '<a href="'.get_permalink().'" class="img_wrap">'.$post_thumbnail.'</a>';
				$return_string .= '<div class="contentpadding">';
				$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
				$return_string .= '<div class="short-post-meta">'.get_the_time('M j').' </div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
			$return_string .= '</div>';
		}			
	}else{
		if($blog_data->have_posts()){
			$return_string .= '<div class="blog_list hook-blog custom-blog">';
			$return_string .= '<div class="row">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				if(has_post_thumbnail()){
					$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
				} else {
					$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
				}			
				if($col == '4'){
					$return_string .= '<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3">';
				}elseif($col == '3'){
					$return_string .= '<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">';
				}elseif($col == '2'){
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">';
				}else{
					$return_string .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">';
				}
				$return_string .= '<div class="sk_box">';
				$return_string .= '<a href="'.get_permalink().'">';
				$return_string .= '<figure>';
				$return_string .= $post_thumbnail;
				$return_string .= '<div class="blog_info">';
				$return_string .= '<span><i class="fa fa-calendar"></i>'.get_the_date().'</span>';
				$return_string .= '</div>';
				$return_string .= '</figure>';
				$return_string .= '<div class="blog_text">';
				$return_string .= '<h2 class="subheading">'.get_the_title().'</h2>';
				$return_string .= '<div class="blog_para"><p>'.get_the_excerpt().'</p></div>';
				$return_string .= '<span class="readmore">Read More</span>';
				$return_string .= '</div>';
				$return_string .= '</a>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';			
		}
	}
	wp_reset_postdata();

	return $return_string;
}


function constructionpress_blog_fullwidth_listing($atts){
	ob_start();
	$return_string = '';
	extract( shortcode_atts( array(
		'limit' => '10',      // -1 == all posts
		'category_id' => '',      // '' == all category
		'post__not_in' => array(1),
	), $atts ) );
	$paged = get_query_var('paged') ? get_query_var('paged') : 1;

	if(!empty($category_id)){
		$blog_args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => $limit,
			'cat' => $category_id,
			'paged' => $paged
		);
	} else {
		$blog_args = array(
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => $limit,
			'paged' => $paged
		);
	}

	$blog_data = new WP_Query($blog_args);
	
		if($blog_data->have_posts()){

			$return_string .= '<div class="design-wrapper fullwidth">';
			$return_string .= '<div class="row">';
			while($blog_data->have_posts()) : $blog_data->the_post();
				

				$return_string .= '<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">';
					
					if(has_post_thumbnail()){
						$post_thumbnail = get_the_post_thumbnail( get_the_ID(), 'full', array( 'class' => 'aligncenter' ) );
					} else {
						$post_thumbnail = get_template_directory_uri().'/assets/images/blog.jpg';
					}
				

				$return_string .= '<div class="item">';
				$return_string .= '<a href="'.get_permalink().'" class="img_wrap">'.$post_thumbnail.'</a>';

				$return_string .= '<div class="content">';
				$return_string .= '<h2><a href="'.get_permalink().'">'.get_the_title().'</a></h2>';
				$return_string .= '<div class="short-post-meta"><ul class="post-meta"><li class="author">'.get_the_author_meta('display_name').'</li><li class="time">'.get_the_time('M j, Y').'</li><li class="category">'.get_the_category_list(', ').'</li></ul> </div>';
				$return_string .= '<p>'.get_the_excerpt().'</p>';
				$return_string .= '<div class="readmore"><a href="'.get_permalink().'">Continue reading &nbsp;<i class="fa fa-long-arrow-right" aria-hidden="true"></i></a></div>';

				$return_string .= '</div>';
				$return_string .= '</div>';
				$return_string .= '</div>';
			endwhile;
			$return_string .= '</div>';
			$return_string .= '</div>';
		}

	wp_reset_postdata();
 

	if(function_exists('wp_pagenavi')) { 	
		$return_string .= '<div class="theme-pagi design-wrapper fullwidth"><div class="row"><div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">';
		$return_string .= wp_pagenavi(array( 'query' => $blog_data, 'echo' => false ));
		$return_string .= '</div></div></div>';
	}
	

	return $return_string;
}
add_shortcode('blog-fullwidth-listng', 'constructionpress_blog_fullwidth_listing');


?>